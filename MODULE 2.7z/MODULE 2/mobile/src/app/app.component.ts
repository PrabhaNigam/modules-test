
import { Component } from '@angular/core';
import { HttpErrorResponse, HttpClientModule, HttpClient, } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Mobile Details!!';




  delete(i): any 
  {
    this.mobileArray.splice(i, 1)
    this.title = "Data Deleted";
  }



  sortBy(header: string)
   {
    this.mobileArray.sort((mob1, mob2) => mob1[header] > mob2[header] ? 1 : -1)
    this.title = "Data Sorted";
  }

  constructor(private httpService: HttpClient) { }
  mobileArray: string[];


  ngOnInit() {
    this.httpService.get('./assets/mobile.json').subscribe(
      data => {
        this.mobileArray = data as string[];

      },
      (err: HttpErrorResponse) => {
        console.log(err.message);
      }
    );
  }
}